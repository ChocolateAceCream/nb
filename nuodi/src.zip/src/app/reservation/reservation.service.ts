import { Reservation } from './reservation.model';
import { Response } from './response.model';
import { Subject } from 'rxjs/Subject';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { UIService } from '../shared/ui.service';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class ReservationService {
    token: string;
    reChanged = new Subject<Reservation[]>();
    reservations: Reservation[] = [];
    private reservation: Reservation

    constructor(
        private http: HttpClient,
        private uiService: UIService
    ) {}

    ngOnInit() {
    }

    getAllReservations() {
        this.token = localStorage.getItem('accessToken');
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type':'application/json',
                'Access-Control-Allow-Origin':"*",
                'Authorization':`Bearer ${this.token}`
            })
        };
        this.http.post<Response>(
            `http://113.128.65.64:3002/rest/config/get`,
            {device_id: "ab111"},
            httpOptions
        ).toPromise()
        .then((results: Response) => {
            console.log(results);
            this.reChanged.next(results.result);
            this.reservations = results.result;
        })
        .catch(error => {
        })

    }

    newReservation(reservationData: Reservation) {
        this.token = localStorage.getItem('accessToken');

        this.uiService.loadingStateChanged.next(true);
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type':'application/json',
                'Access-Control-Allow-Origin':"*",
                'Authorization':`Bearer ${this.token}`
            })
        };
        this.http.post(
            `http://113.128.65.64:3002/rest/config/new`,
            reservationData,
            httpOptions
        ).toPromise()
        .then(result => {
            this.uiService.loadingStateChanged.next(false);
            this.uiService.showSnackbar("Reservation Done",null,5000)
            this.getAllReservations()
        })
        .catch(error => {
            this.uiService.loadingStateChanged.next(false);
            this.uiService.showSnackbar(error.error.errors[0].detail,null,3000)
        })

    }

    cancelReservation() {

    }
}
