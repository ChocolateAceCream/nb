import { Reservation } from './reservation.model';
export interface Response{
    status: number;
    msg: string;
    result: Reservation[];
}
