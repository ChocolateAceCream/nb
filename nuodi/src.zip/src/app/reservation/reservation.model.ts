export interface Reservation {
    device_id: string;
    device_name: string;
}
