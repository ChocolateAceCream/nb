export interface AuthData {
	name: string;
    password: string;
}
